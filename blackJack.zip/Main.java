import java.util.Scanner;
class Main {  
  public static void main(String[] args) {
    Scanner kboard = new Scanner(System.in);
    Deck theDeck = new Deck(1, true);

    //initialize player objects
    Player me = new Player("Collin");
    Player dealer = new Player("dealer");

    me.dealCard(theDeck.dealTopCard());
    dealer.dealCard(theDeck.dealTopCard());
    me.dealCard(theDeck.dealTopCard());
    dealer.dealCard(theDeck.dealTopCard());

    //print starting hands
    System.out.println("Cards are dealt\n");
    me.printHand(true);
    dealer.printHand(false);
    System.out.println("\n");

    //Flags for when each player is finished hitting
    boolean meDone = false;
    boolean dealerDone = false;
    String ans;

    while(!meDone || !dealerDone){
      //players turn
      if(!meDone){
        System.out.println("Hit or Stay? (Enter H or S: )");
        ans = kboard.next();
        System.out.println();

        //if the player hits
        if(ans.compareToIgnoreCase("H") == 0){
          //add next card in deck and store wether player is busted
          meDone = !me.dealCard(theDeck.dealTopCard());
          me.printHand(true);

        } else{
          meDone = true;
        }
      }
      //dealers turn
      if(!dealerDone){
        if(dealer.handSum()< 17){
          System.out.println("The dealer hits\n");
          dealerDone = !dealer.dealCard(theDeck.dealTopCard());
          dealer.printHand(false);
        } else{
          System.out.println("The dealer stays\n");
          dealerDone = true;
        }
      }
      System.out.println();
    }
    //close scanner
    kboard.close();

    //printing final hands
    me.printHand(true);
    dealer.printHand(true);

    int mySum = me.handSum();
    int dealerSum = dealer.handSum();

    if(mySum > dealerSum && mySum <= 21 || dealerSum> 21){
      System.out.println("You Win!");
    } else {
      System.out.println("Dealer Wins!");
    }
  }
}