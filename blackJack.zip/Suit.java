// enum for all possible suits a card can be
public enum Suit{
  Clubs,
  Diamonds,
  Spades,
  Hearts, 
}