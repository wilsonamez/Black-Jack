public class Card{
  //One of four different suits
  private Suit mySuit;
  //Number of cards. Ace = 1, Jack-King = 11-13
  private int myNumber;


  //Card constructor - Takes suit and number of card
  public Card(Suit aSuit, int aNumber){
    mySuit = aSuit;

    if(aNumber >= 1 && aNumber <= 13){
      myNumber = aNumber;
    }else{
      System.err.println(aNumber + " is not a valid card number");
      //exits and tells the blackjack program that there was an error
      System.exit(1);
    }
    
  }

  public int getNumber(){
    return myNumber;
  }

  public String toString(){
    String numStr = "error";
//using switch statement to avoid making a big block of if elses and or an array that calls strings using indexes
    switch(myNumber){
      case 2:
        numStr = "Two";
        break;
      case 3:
        numStr = "Three";
        break;
      case 4:
        numStr = "Four";
        break;
      case 5:
        numStr = "Five";
        break;
      case 6:
        numStr = "Six";
        break;
      case 7:
        numStr = "Seven";
        break;
      case 8:
        numStr = "Eight";
        break;
      case 9:
        numStr = "Nine";
        break;
      case 10:
        numStr = "Ten";
        break;
      case 11:
        numStr = "Jack";
        break;
      case 12:
        numStr = "Queen";
        break;
      case 13:
        numStr = "King";
        break;
      case 1:
        numStr = "Ace";
        break;
    }
    return numStr + " of " + mySuit.toString();
  }
}