import java.util.Random;
import java.util.ArrayList;
public class Deck{
  // Array of cards in the deck with the top card being the first index
  private ArrayList<Card> myCards;
  //number of cards currently in deck
  private int numCards;

  //No arg- constructor
  //Default of one deck (52 cards) and no shuffling
  public Deck(){
    //calls other constructor defining one un shuffled deck
    this(1, false);
  }
  // deck constructor
  public Deck(int numDecks, boolean shuffle){
    numCards = numDecks * 52;
    myCards = new ArrayList<Card>();

    //starting card index
    int i = 0;
    
    //for each deck
    for(int d = 0; d<numDecks; d++){
      //for each suit
      for(int s = 0; s<4; s++){
        //for each num
        for(int n = 1; n<= 13; n++){
          //adds cards to the new deck
          //Card aCard = new Card(Suit.values()[s], n);
          myCards.add( i, new Card(Suit.values()[s], n));
          i++;
        }
      }
    }
    //shuffles cards if necessary
    if(shuffle){
      shuffle();
    }
  }

  //shuffles decks by randomly swapping pairs of cards
  public void shuffle(){
    //random number genorator
    Random rnd = new Random();

    //temp placeholder card
    Card temp;

    int j;
    for(int i = 0; i < numCards; i++){
      //gets random card (j) to swap with i's value
      j = rnd.nextInt(numCards);

      // swapping
      temp = myCards.get(i);
      myCards.set(i, myCards.get(j));
      myCards.set(j, temp);
    }
    
  }

  public Card dealTopCard(){
    //gets next/ top card
    Card top = myCards.get(0);
    myCards.remove(0);

    //decrement number of cards in deck
    numCards--;
    
    return top;
  }
  
  public void printDeck(int numToPrint){
    //print top cards of deck
    for(int i = 0; i < numToPrint; i++){
      System.out.println((i+1) + ". " + numCards + " " + myCards.get(i).toString());
    }
    System.out.println(numCards - numToPrint + " others");
  }
}