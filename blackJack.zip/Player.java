import java.util.ArrayList;

public class Player {
  private String name;
  // cards in the player's hand
  private ArrayList<Card> hand = new ArrayList<Card>();

  private int numCards;

  // player constructor
  public Player(String aName) {
    name = aName;

    // make sure players hand is empty
    emptyHand();
  }

  public void emptyHand() {
    for (int i = 0; i < hand.size(); i++) {
      hand.remove(i);
      i--;
    }
    numCards = 0;
  }

  // dealCard deals a card to the player's hand while also checking if the hand is
  // below or equal to 21
  public boolean dealCard(Card aCard) {
    hand.add(aCard);
    numCards++;

    return (handSum() <= 21);
  }

  public int handSum() {
    int handSum = 0;
    int cardNum;
    int numAces = 0;

    // calculate each card's respective value to total sum of hand
    for (int i = 0; i < numCards; i++) {
      // get value of current card
      cardNum = hand.get(i).getNumber();

      if (cardNum == 1) {// Ace
        numAces++;
        handSum += 11;
      } else if (cardNum > 10) {// face card
        handSum += 10;
      } else {
        handSum += cardNum;
      }
    }
    // if we have any aces and the total turns out to be more than 21, we subtract
    // 10.
    while (handSum > 21 && numAces > 0) {
      handSum -= 10;
      numAces--;
    }

    return handSum;
  }

  // prints the cards in the players current hand
  // showFirstCard whether the first card is hidden or not
  public void printHand(boolean showFirstCard) {
    System.out.println("  " + name + "'s cards:");
    for (int i = 0; i < numCards; i++) {
      if (i == 0 && !showFirstCard) {
        System.out.println("  [locked]  ");
      } else {
        System.out.println(hand.get(i).toString());
      }
    }
  }
}